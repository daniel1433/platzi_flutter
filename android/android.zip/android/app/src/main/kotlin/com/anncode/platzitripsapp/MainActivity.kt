package com.anncode.platzitripsapp

import android.annotation.TargetApi
import android.os.Build
import android.os.Bundle

import io.flutter.embedding.android.FlutterActivity
import io.flutter.plugins.GeneratedPluginRegistrant

class MainActivity: FlutterActivity() {
  
}
